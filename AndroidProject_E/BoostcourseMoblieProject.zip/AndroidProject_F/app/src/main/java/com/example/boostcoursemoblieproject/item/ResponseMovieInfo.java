package com.example.boostcoursemoblieproject.item;

public class ResponseMovieInfo {

    private String message;
    private int code;

    public String getMessage() {
        return message;
    }

    public int getCode() {
        return code;
    }

}
